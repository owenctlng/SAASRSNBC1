<?php 
$page = "auth"; 
$bodyClass = "pt-24 bg-white"; 
include('includes/header.php'); 
?>

<?php
session_start();
include("../database/connection.php");

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR student_id = ?");
    $stmt->bind_param("ss", $email, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();
        
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            
            if($user['role'] == 'admin'){
                header("Location: admin/dashboard.php");
            } else {
                header("Location: user/dashboard.php");
            }
            exit();
        } else {
            $error = "Incorrect password";
        }
    } else {
        $error = "User not found";
    }
    $stmt->close();
}
?>

<!--  MAIN LAYOUT -->
<div class="min-h-screen flex flex-col">

 <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Flowbite -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        secondary: '#fbbf24',
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>

    <!-- CENTER CONTENT -->
    <div class="flex-grow flex items-center justify-center bg-gradient-to-br from-blue-800 via-blue-600 to-blue-500 min-h-screen p-4">

        <div class="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden mt-20">

            <!-- Header -->
            <div class="text-center pt-8 pb-4 px-8">
                <div class="relative w-24 h-24 mx-auto mb-4">
                    <img src="img/logo.png" class="w-full h-full object-contain drop-shadow-md">
                </div>
                
                <h1 class="text-3xl font-bold text-gray-800 mb-1">NORSU Bais</h1>
                <p class="text-gray-500 text-sm">Student Appointment System</p>
            </div>

            <div class="px-8 pb-8">

               <!-- Error Alert -->
            <?php if(isset($error)): ?>
            <div class="mb-4 p-4 text-sm text-red-700 bg-red-100 rounded-lg border border-red-200 flex items-center animate-fade-in" role="alert">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" class="space-y-5">
                <!-- Email/Student ID Field -->
                <div>
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-700">
                        Student ID / Email
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="text" id="email" name="email" 
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-3 transition-all duration-200 hover:border-blue-300" 
                            placeholder="Enter your student ID or email" required>
                    </div>
                </div>

                <!-- Password Field -->
                <div>
                    <label for="password" class="block mb-2 text-sm font-medium text-gray-700">
                        Password
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="password" name="password" 
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-3 transition-all duration-200 hover:border-blue-300" 
                            placeholder="Enter your password" required>
                        <button type="button" onclick="togglePassword()" class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600 cursor-pointer">
                            <i class="fas fa-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <!-- Login Button -->
                <button type="submit" name="login" 
                    class="w-full text-white bg-blue-800 hover:bg-blue-900 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-3 text-center transition-all duration-200 transform hover:scale-[1.02] shadow-lg hover:shadow-xl">
                    Login
                </button>
            </form>

            <!-- Links -->
            <div class="flex justify-between items-center mt-6 text-sm">
                <a href="signup.php" class="text-blue-700 hover:text-blue-800 font-medium hover:underline transition-colors">
                    Register Account
                </a>
                <a href="#" class="text-gray-600 hover:text-gray-800 font-medium hover:underline transition-colors">
                    Forgot Password?
                </a>
            </div>

            <!-- Divider -->
            <div class="relative flex py-5 items-center">
                <div class="flex-grow border-t border-gray-300"></div>
                <span class="flex-shrink-0 mx-4 text-gray-400 text-sm font-medium">OR</span>
                <div class="flex-grow border-t border-gray-300"></div>
            </div>

            <!-- One-Time Request Button -->
            <button type="button" 
                class="w-full text-blue-800 bg-white border-2 border-yellow-400 hover:bg-yellow-50 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-3 text-center transition-all duration-200 transform hover:scale-[1.02] shadow-md">
                One-Time Request
            </button>

            <!-- Demo Note -->
            <div class="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
                <p class="text-center text-xs text-gray-600">
                    <span class="font-semibold text-blue-800">Demo:</span> Use "admin@norsu.edu" for admin or any other email for student
                </p>
            </div>

            <!-- Back to Home -->
            <div class="text-center mt-6">
                <a href="../src/home.php" class="inline-flex items-center text-sm font-medium text-gray-600 hover:text-blue-700 transition-colors group">
                    <i class="fas fa-arrow-left mr-2 transform group-hover:-translate-x-1 transition-transform"></i>
                    Back to Home
                </a>
            </div>
        </div>
    </div>

</div>

<!-- JS -->
<script>
function togglePassword() {
    const password = document.getElementById("password");
    const icon = document.getElementById("eyeIcon");

    if(password.type === "password"){
        password.type = "text";
        icon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        password.type = "password";
        icon.classList.replace("fa-eye-slash", "fa-eye");
    }
}
</script>

<?php include('includes/footer.php'); ?>
