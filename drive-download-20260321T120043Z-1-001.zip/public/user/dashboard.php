<?php 
session_start();

// 🔒 PROTECT PAGE (must login)
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$pageTitle = "Student Dashboard";
?>
<script src="https://cdn.tailwindcss.com"></script>
    <!-- Flowbite -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>

<div class="flex min-h-screen">

    <!-- SIDEBAR -->
    <aside class="w-64 bg-blue-900 text-white flex flex-col">

        <div class="p-5 border-b border-blue-800">
            <h1 class="text-lg font-bold">NORSU Bais</h1>
            <p class="text-sm text-blue-200">Academic Services</p>
        </div>

        <nav class="flex-1 p-4 space-y-2">

            <a href="#" class="flex items-center p-3 bg-blue-700 rounded-lg">
                <i class="fas fa-home mr-3"></i> Dashboard
            </a>

            <a href="#" class="flex items-center p-3 hover:bg-blue-700 rounded-lg">
                <i class="fas fa-calendar mr-3"></i> My Appointments
            </a>

            <a href="#" class="flex items-center p-3 hover:bg-blue-700 rounded-lg">
                <i class="fas fa-file mr-3"></i> My Requests
            </a>

        </nav>

        <div class="p-4 border-t border-blue-800">
            <a href="../logout.php" class="flex items-center p-3 hover:bg-blue-700 rounded-lg">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </div>

    </aside>

    <!-- MAIN -->
    <main class="flex-1">

        <!-- TOPBAR -->
        <div class="bg-white shadow p-4 flex justify-between items-center">

            <h2 class="text-xl font-semibold">
                Student Appointment & Academic Services
            </h2>

            <div class="flex items-center gap-4">

                <!-- USER INFO -->
                <div class="flex items-center gap-2">
                    <div class="bg-yellow-400 w-10 h-10 rounded-full flex items-center justify-center font-bold">
                        <?= strtoupper(substr($_SESSION['name'], 0, 1)); ?>
                    </div>
                    <div>
                        <p class="text-sm font-semibold">
                            <?= $_SESSION['name']; ?>
                        </p>
                        <p class="text-xs text-gray-500">
                            <?= $_SESSION['course']; ?>
                        </p>
                    </div>
                </div>

            </div>
        </div>

        <!-- CONTENT -->
        <div class="p-6 space-y-6">

            <!-- WELCOME -->
            <div>
                <h1 class="text-2xl font-bold">
                    Welcome back, <?= explode(' ', $_SESSION['name'])[0]; ?>!
                </h1>
                <p class="text-gray-500">Here's what's happening today.</p>
            </div>

            <!-- CARDS -->
            <div class="grid grid-cols-4 gap-4">

                <div class="bg-white p-4 rounded-xl shadow">
                    <p>Total Requests</p>
                    <h2 class="text-2xl font-bold">0</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p>Pending</p>
                    <h2 class="text-2xl font-bold">0</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p>Approved</p>
                    <h2 class="text-2xl font-bold">0</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p>Rejected</p>
                    <h2 class="text-2xl font-bold">0</h2>
                </div>

            </div>

        </div>

    </main>

</div>

<?php include('../includes/footer.php'); ?>
