<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ================= HEAD ================= -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NORSU Academic Services</title>

    <!-- Tailwind CSS -->
    <link rel="stylesheet" href="../public/assets/css/output.css">
</head>

<body>

<!-- ================= NAVBAR ================= -->
<nav class="bg-blue-700 fixed w-full top-0 left-0 z-50 shadow-md">

    <div class="max-w-screen-xl mx-auto flex items-center justify-between px-6 py-4">

        <!-- Logo -->
        <div class="flex items-center gap-3">
            <img src="../public/img/logo.png" class="h-7">
            <span class="text-white text-xl font-semibold">
                NORSU Bais
            </span>
        </div>

        <!-- Navigation Links -->
        <ul class="hidden md:flex items-center gap-8 font-medium text-white">
         <?php if(!isset($page) || $page !== "auth"): ?>
            <li><a href="#about" class="hover:text-blue-800">About</a></li>
            <li><a href="#services" class="hover:text-blue-800">Services</a></li>
            <li><a href="#contact" class="hover:text-blue-800">Contact Us</a></li>
         <?php endif; ?>
        </ul>

        <!-- Login / Signup Buttons -->
        <div class="flex gap-3">

        <?php if(isset($page) && $page === "auth"): ?>

            <a href="../src/home.php"
            class="text-white border border-white px-4 py-2 rounded-lg">
            ← Back to Home
            </a>
 
        <?php else: ?>

            <a href="../public/login.php" class="text-white border border-white px-4 py-2 rounded-lg">
            Login
            </a>

            <a href="../public/signup.php" class="bg-yellow-400 text-black px-4 py-2 rounded-lg">
            Sign Up
            </a>

        <?php endif; ?>

        </div>


    </div>
</nav>
